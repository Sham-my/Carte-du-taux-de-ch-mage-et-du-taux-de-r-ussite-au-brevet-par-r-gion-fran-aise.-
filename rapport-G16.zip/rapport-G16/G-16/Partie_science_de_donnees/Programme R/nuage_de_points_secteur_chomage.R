if (!requireNamespace("ggplot2", quietly = TRUE)) {
  install.packages("ggplot2")
}
library(ggplot2)

if (!requireNamespace("RColorBrewer", quietly = TRUE)) {
  install.packages("RColorBrewer")
}
library(RColorBrewer)

chom_prive <- read.csv("C:\\Users\\HAMMO\\Desktop\\science de donnée\\tx_chomage,tx_prive_departement.csv", sep = ",", header =  TRUE,
                          col.names = c("tx_chomage","libelle_departement","proportion_prive"),
                          stringsAsFactors = FALSE)
attach(chom_prive)
tx_chomage <- as.integer(tx_chomage)
libelle_departement <- as.factor(libelle_departement)
proportion_prive <- as.factor(proportion_prive)

  correlation <- cor(chom_prive$tx_chomage, chom_prive$proportion_prive)
  print(correlation)
  
  ggplot(chom_prive, aes(x = tx_chomage, y = proportion_prive)) +
    geom_point() +
    labs(title = "Nuage de points de la proportion d'établissements prives en fonction du taux de chömage par département",
         x = "tx_chomage",
         y = "proportion_prive") +
    geom_smooth(method = "lm", se = FALSE, color = "red") + 
    annotate("text", x = min(chom_prive$tx_chomage), y = max(chom_prive$proportion_prive), 
             label = paste("Corrélation linéaire:", round(correlation, 3)), 
             hjust = 0, vjust = 1) 
  print(chom_prive)
  