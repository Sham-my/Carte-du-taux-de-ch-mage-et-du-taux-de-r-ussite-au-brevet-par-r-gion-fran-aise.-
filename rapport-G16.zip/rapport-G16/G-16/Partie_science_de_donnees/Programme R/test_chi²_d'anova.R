if (!requireNamespace("ggplot2", quietly = TRUE)) {
  install.packages("ggplot2")
}
library(ggplot2)

if (!requireNamespace("RColorBrewer", quietly = TRUE)) {
  install.packages("RColorBrewer")
}
library(RColorBrewer)

etablissement <- read.csv("C:\\Users\\HAMMO\\Desktop\\basse_de_données\\donnees_test_chi²_anova.csv", sep = ",", header =  TRUE,
                          col.names = c("Secteur","TX_mention_ab","TX_mention_B","TX_mention_TB"),
                          stringsAsFactors = FALSE)

head(etablissement)
attach(etablissement)
Secteur <- as.factor(Secteur)
tx_mention_ab <- as.numeric(tx_mention_ab)
tx_mention_b <- as.numeric(tx_mention_b)
tx_mention_tb <- as.numeric(tx_mention_tb)



#fonction pour calculer la dispersion INTER avec
#x : variable quantitative
#gpe : variable qualitative
dispinter <- function(x, gpe) {
  moyennes <- tapply(x, gpe, mean)
  effectifs <- tapply(x, gpe, length)
  res <- (sum(effectifs * (moyennes - mean(x))^2))
  return(res)
}
#fonction pour calculer la dispersion INTRA avec
#x : variable quantitative
#gpe : variable qualitative
dispintra <- function(x, gpe) {
  effectifs <- tapply(x, gpe, length)
  varest <- tapply(x, gpe, var)
  return(sum((effectifs - 1) * varest))
}

#test du chi² d'anova pour la variable tx_mention_ab
#𝐇: La distribution de la mention assez bien est identique dans tous les groupes.
chi2_anova_ab <- (nrow(etablissement)-2)*(dispinter(tx_mention_ab,Secteur)/(dispintra(tx_mention_ab,Secteur)))
cat(chi2_anova_ab,">", qchisq(0.95,1),", on ne rejette pas l'hypothèse H.")


# Création du graphique avec chatgpt
par(bty = "n")

# Création du graphique
boxplot(tx_mention_ab ~ Secteur, 
        data = etablissement, 
        col = brewer.pal(5, "Set2"), 
        notch = TRUE,
        varwidth = TRUE, 
        main = "Boxplot du taux de mention AB par secteur d'enseignement",
        xlab = "Taux de mention AB",
        ylab = "Secteur d'enseignement",
        border = "gray", 
        horizontal = TRUE, 
        cex.axis = 0.8,
        cex.lab = 1,
        cex.main = 1.2,
        font.main = 2
)


#//////////////////////////////////


#test du chi² d'anova pour la variable tx_mention_b
#𝐇: La distribution de la mention bien est identique dans tous les groupes.
chi2_anova_b <- (nrow(etablissement)-2)*(dispinter(tx_mention_b,Secteur)/(dispintra(tx_mention_b,Secteur)))
cat(chi2_anova_b, ">", qchisq(0.95,1),", on ne rejette pas l'hypothèse H.")


par(bty = "n")

# Création du graphique
boxplot(tx_mention_b ~ Secteur, 
        data = etablissement, 
        col = brewer.pal(5, "Set2"), 
        notch = TRUE,
        varwidth = TRUE, 
        main = "Boxplot du taux de mention B par secteur d'enseignement",
        xlab = "Taux de mention B",
        ylab = "Secteur d'enseignement",
        border = "gray", 
        horizontal = TRUE,
        cex.axis = 0.8,
        cex.lab = 1,
        cex.main = 1.2,
        font.main = 2
)


#\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\


#test du chi² d'anova pour la variable tx_mention_tb
#𝐇: La distribution de la mention très bien est identique dans tous les groupes.
chi2_anova_tb <- (nrow(etablissement)-2)*(dispinter(tx_mention_tb,Secteur)/(dispintra(tx_mention_tb,Secteur)))
cat(chi2_anova_tb,">", qchisq(0.95,1),", on ne rejette pas l'hypothèse H.")


par(bty = "n")

boxplot(tx_mention_tb ~ Secteur, 
        data = etablissement,
        col = brewer.pal(5, "Set2"), 
        notch = TRUE,
        varwidth = TRUE, 
        main = "Boxplot du taux de mention TB par secteur d'enseignement",
        xlab = "Taux de mention tB",
        ylab = "Secteur d'enseignement",
        border = "gray", 
        horizontal = TRUE,
        cex.axis = 0.8,
        cex.lab = 1,
        cex.main = 1.2,
        font.main = 2
)


