if (!requireNamespace("ggplot2", quietly = TRUE)) {
  install.packages("ggplot2")
}

library(ggplot2)
donnees_test_1 <- read.csv("C:\\Users\\rayan\\OneDrive\\Bureau\\science de donnée Rayane\\departement.csv", sep = ",", header = TRUE,
                        col.names = c("departement", "moyenne_tx_reussite","tx_chomage"),
                        stringsAsFactors = FALSE)

str(donnees_test_1)
library(ggplot2)

correlation <- cor(donnees_test_1$tx_chomage, donnees_test_1$moyenne_tx_reussite)
print(correlation)

ggplot(donnees_test_1, aes(x = tx_chomage, y = moyenne_tx_reussite)) +
  geom_point() +
  labs(title = "Nuage de points par departement",
       x = "tx_chomage",
       y = "moyenne_tx_reussite") +
  geom_smooth(method = "lm", se = FALSE, color = "red") + 
  annotate("text", x = min(donnees_test_1$tx_chomage), y = max(donnees_test_1$moyenne_tx_reussite), 
           label = paste("Corrélation linéaire:", round(correlation, 3)), 
           hjust = 0, vjust = 1) 
print(donnees_test_1)

A <- lm(moyenne_tx_reussite ~ tx_chomage,donnees_test_1)

print(coefficients(A))

